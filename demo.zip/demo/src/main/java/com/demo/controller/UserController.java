package com.demo.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.demo.entity.loginTable;

import com.demo.service.ServiceImpl;




@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
public class UserController {
	
    @Autowired
	private ServiceImpl service ;
	

	@PostMapping("/login")
	public void Login(@RequestBody loginTable login)
	{
     service.Login(login);
	}
	
	
}




